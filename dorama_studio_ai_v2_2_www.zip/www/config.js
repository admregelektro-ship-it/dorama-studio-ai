// Dorama Studio AI: configuração compatível com o aplicativo Android.
window.DORAMA_CONFIG = window.DORAMA_CONFIG || {};
window.DORAMA_CONFIG.backendUrl = localStorage.getItem('dorama_backend_url') || window.DORAMA_CONFIG.backendUrl || '';
window.DORAMA_CONFIG.appVersion = '2.1.0';
window.DORAMA_CONFIG.platform = 'android';
window.setDoramaBackend = function(url){
  localStorage.setItem('dorama_backend_url', String(url || '').replace(/\/$/, ''));
  location.reload();
};
