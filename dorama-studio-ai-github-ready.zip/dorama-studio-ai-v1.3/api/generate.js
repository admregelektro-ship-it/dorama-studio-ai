const MODEL = process.env.DORAMA_AI_MODEL || 'alibaba/qwen3-max';

function jsonFromText(text) {
  const clean = text.trim().replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '');
  return JSON.parse(clean);
}

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'METHOD_NOT_ALLOWED' });
  try {
    const { series, episode } = req.body || {};
    if (!series || !episode) return res.status(400).json({ error: 'INVALID_REQUEST' });

    const token = process.env.AI_GATEWAY_API_KEY || process.env.VERCEL_OIDC_TOKEN;
    if (!token) return res.status(503).json({ error: 'AI_NOT_CONFIGURED', message: 'Configure AI Gateway/OIDC no servidor.' });

    const ep = series.episodes?.[episode - 1] || {};
    const compact = {
      title: series.title,
      premise: series.premise,
      genre: series.genre,
      country: series.country,
      tone: series.tone,
      rating: series.rating,
      ending: series.ending,
      characters: series.characters,
      seasonPlan: series.episodes?.map(({number,title,summary}) => ({number,title,summary})),
      narrativeMemory: series.memory || [],
      targetEpisode: { number: episode, title: ep.title, summary: ep.summary }
    };

    const prompt = `Você é o roteirista-chefe do Dorama Studio AI. Escreva SOMENTE JSON válido, sem markdown.\n\nMantenha continuidade absoluta com a memória narrativa e o plano da temporada. Preserve personalidade, relações, segredos e fatos já estabelecidos. Adapte nomes, lugares e costumes ao país escolhido, sem caricaturas. Respeite a classificação indicativa.\n\nCrie o episódio solicitado com ritmo de dorama e diálogos naturais em português do Brasil. Retorne exatamente esta estrutura:\n{"summary":"resumo do episódio","script":{"scenes":[{"place":"local","time":"horário","action":"descrição dramática da cena","dialogue":[{"name":"personagem","text":"fala"}]}],"hook":"gancho final"},"memory":"registro curto dos fatos novos que precisam ser lembrados nos próximos episódios"}\n\nDNA DO DORAMA:\n${JSON.stringify(compact)}`;

    const response = await fetch('https://ai-gateway.vercel.sh/v1/chat/completions', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: MODEL, messages: [{ role: 'user', content: prompt }] })
    });
    const raw = await response.json();
    if (!response.ok) throw new Error(raw?.error?.message || 'Falha no AI Gateway');
    const text = raw?.choices?.[0]?.message?.content;
    if (!text) throw new Error('Resposta vazia da IA');
    const result = jsonFromText(text);
    if (!result.script?.scenes || !result.script?.hook) throw new Error('Resposta fora do formato esperado');
    return res.status(200).json(result);
  } catch (error) {
    return res.status(500).json({ error: 'AI_GENERATION_FAILED', message: error.message });
  }
}
