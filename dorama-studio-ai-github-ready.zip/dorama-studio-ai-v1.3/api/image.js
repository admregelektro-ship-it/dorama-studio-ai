// Dorama Studio AI v0.6 — contrato do backend visual.
// A geração real deve ocorrer somente no servidor e devolver uma URL/data URL válida.
export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'METHOD_NOT_ALLOWED' });
  const { series, kind, character } = req.body || {};
  if (!series || !['character','poster'].includes(kind)) return res.status(400).json({ error: 'INVALID_REQUEST' });
  const visual = character?.visual || {};
  const identity = character ? `${character.name}, ${character.role}. ${character.bio}. Aparência fixa: ${visual.identity || 'a definir'}. Roupa/estilo: ${visual.style || 'contemporâneo elegante'}.` : '';
  const prompt = kind === 'character'
    ? `Retrato cinematográfico original de personagem de dorama. ${identity} País/ambientação: ${series.country}. Gênero: ${series.genre}. Tom: ${series.tone}. Manter exatamente esta identidade visual em futuras imagens. Sem texto, sem logotipos.`
    : `Pôster vertical cinematográfico original para o dorama “${series.title}”. ${series.genre}, ambientado em ${series.country}, tom ${series.tone}. Elenco e identidades visuais: ${JSON.stringify((series.characters||[]).map(c=>({name:c.name,identity:c.visual?.identity,style:c.visual?.style})))}. Composição premium de streaming, sem copiar obras existentes. Título legível: ${series.title}.`;
  // Endpoint deliberadamente não simula imagem. Quando o provedor for configurado,
  // use este prompt e retorne { imageUrl, prompt }.
  return res.status(503).json({ error:'IMAGE_AI_NOT_CONFIGURED', prompt, message:'Backend visual preparado; conecte um provedor de geração de imagens no servidor.' });
}
